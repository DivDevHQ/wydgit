EVENT Submit
    Dim inputTitle As String
    inputTitle = REQUEST.Form.Get("title")

    Dim inputStatus As String
    inputStatus = REQUEST.Form.Get("status")

    If inputStatus = "" Then
        inputStatus = "todo"
    End If

    Dim rootSec As Wydgit
    SET rootSec = Me.related("parent")

    Dim statusBlock As Wydgit
    FOR EACH node IN rootSec.related("children", "blocks")
        If node.id = "taskboard-status-msg" Then
            SET statusBlock = node
        End If
    NEXT node

    If inputTitle <> "" Then
        Dim recordId As String
        recordId = NewId()

        Dim res As Object
        res = SERVICES.Call("wydstore", "create", {
            "store": "tasks",
            "collection": "tasks",
            "id": recordId,
            "data": {
                "title": inputTitle,
                "status": inputStatus
            }
        })

        If res.ok Then
            statusBlock.content = {
                "type": "markdown",
                "value": "Task created successfully!"
            }

            Dim titleField As Wydgit
            FOR EACH fld IN Me.related("children", "blocks")
                If fld.id = "taskboard-title-field" Then
                    SET titleField = fld
                End If
            NEXT fld

            titleField.value = ""
        Else
            statusBlock.content = {
                "type": "markdown",
                "value": "Failed to create task in store."
            }
        End If
    End If
END EVENT