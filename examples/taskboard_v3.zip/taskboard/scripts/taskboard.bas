EVENT Page.PreRender
    Dim res As Object
    res = SERVICES.Call("wydstore", "query", {
        "store": "tasks",
        "collection": "tasks",
        "limit": 50
    })

    Dim rootSec As Wydgit
    SET rootSec = Me

    Dim statusBlock As Wydgit
    FOR EACH node IN rootSec.related("children", "blocks")
        If node.id = "taskboard-status-msg" Then
            SET statusBlock = node
        End If
    NEXT node

    If res.ok Then
        Dim listSec As Wydgit
        Dim colTodo As Wydgit
        Dim colDoing As Wydgit
        Dim colDone As Wydgit

        FOR EACH childNode IN rootSec.related("children", "blocks")
            If childNode.id = "taskboard-list-section" Then
                SET listSec = childNode
            End If
        NEXT childNode

        FOR EACH colNode IN listSec.related("children", "blocks")
            If colNode.id = "col-todo" Then
                SET colTodo = colNode
            ElseIf colNode.id = "col-doing" Then
                SET colDoing = colNode
            ElseIf colNode.id = "col-done" Then
                SET colDone = colNode
            End If
        NEXT colNode

        Dim records As Array
        records = res.value

        Dim taskData As Object
        Dim titleStr As String
        Dim statusStr As String
        Dim recId As String
        Dim cardId As String
        Dim card As Wydgit
        Dim targetCol As Wydgit

        Dim idxTodo As Number
        Dim idxDoing As Number
        Dim idxDone As Number
        idxTodo = 1
        idxDoing = 1
        idxDone = 1

        Dim targetIdx As Number
        Dim nextStatus As String

        FOR EACH rec IN records
            recId = rec.id
            taskData = rec.data
            titleStr = taskData.title
            statusStr = taskData.status

            If statusStr = "doing" Then
                SET targetCol = colDoing
                targetIdx = idxDoing
                idxDoing = idxDoing + 1
                nextStatus = "done"
            ElseIf statusStr = "done" Then
                SET targetCol = colDone
                targetIdx = idxDone
                idxDone = idxDone + 1
                nextStatus = "todo"
            Else
                SET targetCol = colTodo
                targetIdx = idxTodo
                idxTodo = idxTodo + 1
                nextStatus = "doing"
            End If

            cardId = "task-card-" & recId
            SET card = NEW "divdev/task-card"(cardId)
            card.taskTitle = titleStr
            card.status = statusStr
            card.recordId = recId

            ' 1. Card Title Block
            Dim titleBlock As Wydgit
            SET titleBlock = NEW "wydgit.core/block"(cardId & "-title")
            titleBlock.content = {
                "type": "markdown",
                "value": "**" & titleStr & "**"
            }
            card.Insert("blocks", 0, titleBlock)

            ' 2. Move Action Form
            Dim moveForm As Wydgit
            SET moveForm = NEW "wydgit.core/form"(cardId & "-move-form")

            Dim recIdHiddenMove As Wydgit
            SET recIdHiddenMove = NEW "wydgit.core/hidden-input"(cardId & "-move-recid")
            recIdHiddenMove.name = "recordId"
            recIdHiddenMove.value = recId
            moveForm.Insert("blocks", 0, recIdHiddenMove)

            Dim nextStatusHidden As Wydgit
            SET nextStatusHidden = NEW "wydgit.core/hidden-input"(cardId & "-move-status")
            nextStatusHidden.name = "targetStatus"
            nextStatusHidden.value = nextStatus
            moveForm.Insert("blocks", 1, nextStatusHidden)

            card.Insert("blocks", 1, moveForm)

            ' 3. Delete Action Form
            Dim delForm As Wydgit
            SET delForm = NEW "wydgit.core/form"(cardId & "-delete-form")

            Dim recIdHiddenDel As Wydgit
            SET recIdHiddenDel = NEW "wydgit.core/hidden-input"(cardId & "-del-recid")
            recIdHiddenDel.name = "recordId"
            recIdHiddenDel.value = recId
            delForm.Insert("blocks", 0, recIdHiddenDel)

            card.Insert("blocks", 2, delForm)

            targetCol.Insert("blocks", targetIdx, card)
        NEXT rec
    Else
        statusBlock.content = {
            "type": "markdown",
            "value": "Failed to load tasks from storage."
        }
    End If
END EVENT